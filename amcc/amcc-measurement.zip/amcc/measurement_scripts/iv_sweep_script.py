#%%============================================================================
# Instrument setup
#==============================================================================
import numpy as np
import time
from tqdm import tqdm
import datetime
import pickle
import visa

from matplotlib import pyplot as plt
from amcc.standard_measurements.iv_sweep import run_iv_sweeps, setup_iv_sweep
from amcc.instruments import RigolDG5000
from amcc.instruments import LeCroy620Zi
from amcc.instruments import Switchino

# Close all open resources
rm = visa.ResourceManager()
[i.close() for i in rm.list_opened_resources()]

lecroy_ip = '192.168.1.100'
lecroy = LeCroy620Zi("TCPIP::%s::INSTR" % lecroy_ip)
awg = RigolDG5000('USB0::0x1AB1::0x0640::DG5T171200124::INSTR')
switch = Switchino('COM7')


#%%============================================================================
# Initialize instruments
#==============================================================================
lecroy.reset()
time.sleep(0.5)
setup_iv_sweep(lecroy, awg, vpp = 1, repetition_hz = 10, trigger_level = 0,
               num_datapoints = 10e3, trigger_slope = 'Positive')

awg.setup_dc(voffset = 0.0, channel = 2)


#%%============================================================================
# # Helper functions
# =============================================================================

def awg_set_current(i):
    awg.set_voffset(i*exp_iv['R_current_bias'], channel = 2)



def iv(port = None):
    if port is not None:
        switch.select_port(port, switch = 1)
    exp_iv['vpp'] = awg.get_vpp()
    exp_iv['repetition_hz'] = awg.get_freq()
    V, I = run_iv_sweeps(lecroy, num_sweeps = exp_iv['num_sweeps'], R = exp_iv['R_AWG'])
    return V, I

def iv_vs_current(i):
    awg.set_output(True, channel = 2)
    awg_set_current(i)
    time.sleep(0.1)
    V, I = iv()
    awg.set_output(False, channel = 2)
    return (V,I)


def iv_vs_current_vs_port(i, port_pair):
    switch.select_ports(port_pair)
    return iv_vs_current(i)

def plot_iv_vs_port(data):
    if share_axes:
        fig, sub_plots = plt.subplots(2,5,sharex=True, sharey=True, figsize = [16,8])
    else:
        fig, sub_plots = plt.subplots(2,5, figsize = [16,8])
    sub_plots = np.ravel(sub_plots) # Convert 2D array of sub_plots to 1D
    for n, (port, iv_data) in enumerate(data.items()):
        V, I = iv_data
    #    plt.subplot(2,5,port)
        sub_plots[port-1].plot(V*1e3, I*1e6,'.')
        sub_plots[port-1].set_title('Port %s' % port)
        sub_plots[port-1].set_xlabel('Voltage (mV)')
        sub_plots[port-1].set_ylabel('Current (uA)')
    fig.tight_layout()
    fig.suptitle(title); fig.subplots_adjust(top=0.88) # Add supertitle over all subplots
    
    filename = datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S IV sweep')
    pickle.dump({'data':data}, open(filename + '.pickle', 'wb'))
    pickle.dump(fig, open(filename + '.fig.pickle', 'wb'))
    fig.savefig(filename)

#%%============================================================================
# Setup experimental variables
#==============================================================================
exp_iv = {}
exp_iv['test_type'] = 'IV Sweep'
exp_iv['test_name'] = 'HPD48'
exp_iv['R_AWG'] = 10e3
exp_iv['R_current_bias'] = 10e3
exp_iv['num_sweeps'] = 10
exp_iv['vpp'] = 1.5
exp_iv['voffset'] = 0
exp_iv['repetition_hz'] = 10

# Update vpp
awg.set_vpp(vpp = exp_iv['vpp'], channel = 1)
awg.set_voffset(exp_iv['voffset'], channel = 1)

# Update repetition rate
awg.set_freq(freq = exp_iv['repetition_hz'], channel = 1)


#%%============================================================================
# Set vertical scale
#==============================================================================
lecroy.find_vertical_scale(channel = 'C1')
lecroy.find_vertical_scale(channel = 'C2')


#%%============================================================================
# Quick port select
#==============================================================================
#from instruments.switchino import Switchino
#switch = Switchino('COM7')

switch.select_port(1, switch = 1)
switch.select_port(2, switch = 1)
switch.select_port(3, switch = 1)
switch.select_port(4, switch = 1)
switch.select_port(5, switch = 1)
switch.select_port(6, switch = 1)
switch.select_port(7, switch = 1)
switch.select_port(8, switch = 1)
switch.select_port(9, switch = 1)
switch.select_port(10, switch = 1)
switch.disable(switch = 1)

switch.select_port(1, switch = 2)
switch.select_port(2, switch = 2)
switch.select_port(3, switch = 2)
switch.select_port(4, switch = 2)
switch.select_port(5, switch = 2)
switch.select_port(6, switch = 2)
switch.select_port(7, switch = 2)
switch.select_port(8, switch = 2)
switch.select_port(9, switch = 2)
switch.select_port(10, switch = 2)
switch.disable(switch = 2)

switch.disable()

switch.select_ports((3,4))

#%%============================================================================
# Record and plot single IV curve
#==============================================================================

exp_iv['num_sweeps'] = 20
device_name = 'A17 row 6'

v, i = iv()
fig = plt.figure()
plt.plot(v*1e3, i*1e6,'.')
plt.xlabel('Voltage (mV)')
plt.ylabel('Current (uA)')
plt.title(device_name)

data = {'i':i, 'v':v}
filename = datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S IV sweep')
pickle.dump({'data':data}, open(filename + '.pickle', 'wb'))
pickle.dump(fig, open(filename + '.fig.pickle', 'wb'))
plt.savefig(filename)



#%%============================================================================
# Perform IV sweep for each port on switch 1
#==============================================================================
ports = list(range(1,11))
#ports = [1,3,5,7,9]
#ports = [2,3,4]


share_axes = True
reset_vertical_scale = False
#title = 'ncd012 test structures'
title = None

#Run experment
data = {}
for port in tqdm(ports):
    data[port] = iv(port)
    
    if reset_vertical_scale:
        lecroy.find_vertical_scale(channel = 'C2')
        time.sleep(7)


# Plot data
#fig = plt.figure(); fig.set_size_inches([16,8])
if share_axes:
    fig, sub_plots = plt.subplots(2,5,sharex=share_axes, sharey=share_axes, figsize = [16,8])
else:
    fig, sub_plots = plt.subplots(2,5, figsize = [16,8])
sub_plots = np.ravel(sub_plots) # Convert 2D array of sub_plots to 1D
for n, (port, iv_data) in enumerate(data.items()):
    V, I = iv_data
#    plt.subplot(2,5,port)
    sub_plots[port-1].plot(V*1e3, I*1e6,'.')
    sub_plots[port-1].set_title('Port %s' % port)
    sub_plots[port-1].set_xlabel('Voltage (mV)')
    sub_plots[port-1].set_ylabel('Current (uA)')
fig.tight_layout()
if title is not None:
    fig.suptitle(title); fig.subplots_adjust(top=0.88) # Add supertitle over all subplots

# Save data
filename = datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S IV sweep')
pickle.dump({'data':data}, open(filename + '.pickle', 'wb'))
pickle.dump(fig, open(filename + '.fig.pickle', 'wb'))
fig.savefig(filename)
switch.disable()

# #%% Calculate Ic of IV curves
cutoff_voltage = 20e-3
ramp_rate = (exp_iv['vpp']/exp_iv['R_AWG']*2)/(1/exp_iv['repetition_hz']/2)
print('Ramp rate of %s A/s' % ramp_rate)
for port, d in data.items():
    v = d[0]
    i = d[1]
    iclip = i[(v<cutoff_voltage) & (v>-cutoff_voltage)]
    ic = (max(iclip)-min(iclip))/2*1e6
    print('Port %s: %0.1f uA' % (port,ic))
    



#%% Calculate resistance of IV curves
cutoff_current = 20e-6
for port, d in data.items():
    v = d[0]
    i = d[1]
    selection = (i<cutoff_current) & (i>-cutoff_current)
    i = i[selection]
    v = v[selection]
    try:
        idx = np.isfinite(v) & np.isfinite(i)
        p = np.polyfit(i[idx],v[idx],1)
    except: p= [-1]
    print('Port %s: %0.1f Ohm' % (port,p[0]))
    
    
#%%============================================================================
# Perform IV sweep vs current for each port on switch 1
#==============================================================================

port_pairs = [
        (1,2),
        (3,4),
        (5,6),
        (7,8),
        (9,10),
#        (2,1),
#        (4,3),
#        (6,5),
#        (8,7),
#        (10,9),
        ]
currents = np.linspace(-600e-6, 600e-6, 11)
title = 'Flex cable 5'
share_axes = True

#ports = [1,3,5,7,9]
data = []
for port_pair in tqdm(port_pairs):
    for i in currents:
        switch.select_ports(port_pair)
        V, I = iv_vs_current(i)
        d = {
                'V': V,
                'I': I,
                'port_pair' : port_pair,
                'current' : i,
                }
        data.append(d)


# Plot data
#fig = plt.figure(); fig.set_size_inches([16,8])
if share_axes:  f, sub_plots = plt.subplots(2,5,sharex=True, sharey=True, figsize = [16,8])
else:           f, sub_plots = plt.subplots(2,5, figsize = [16,8])
sub_plots = np.ravel(sub_plots) # Convert 2D array of sub_plots to 1D
for n, d in enumerate(data):
#    plt.subplot(2,5,port)
    port_pair = d['port_pair']
    sub_plots[port_pair[0]-1].plot(d['V']*1e3, d['I']*1e6,'.')
    sub_plots[port_pair[0]-1].set_title('Port %s' % [port_pair])
    sub_plots[port_pair[0]-1].set_xlabel('Voltage (mV)')
    sub_plots[port_pair[0]-1].set_ylabel('Current (uA)')
f.tight_layout()
f.suptitle(title); f.subplots_adjust(top=0.88) # Add supertitle over all subplots

filename = datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S IV sweep vs current')
pickle.dump({'data':data}, open(filename + '.pickle', 'wb'))
pickle.dump(fig, open(filename + '.fig.pickle', 'wb'))
plt.savefig(filename)

#%%============================================================================
# Perform IV sweep vs current for each port on switch 1
#==============================================================================

currents = np.linspace(-50e-6, 50e-6, 2)
data = {i:iv_vs_current(i) for i in tqdm(currents)}

# Plot
fig = plt.figure(); fig.set_size_inches([12,8])
for i, iv_data in data.items():
    V, I = iv_data
    plt.plot(V*1e3, I*1e6,'.', label = 'Ibias = %0.1f uA' % (i*1e6))
plt.xlabel('Voltage (mV)')
plt.ylabel('Current (uA)')
plt.legend()




#%%============================================================================
# Perform IV vs current for several port pairs
#==============================================================================
# (,),
port_pairs = [
        (3,4),
        (5,6),
        (7,8),
        (9,10),
        ]
currents = np.linspace(0, 50e-6, 6)


data = {port_pair : {i:iv_vs_current_vs_port(i, port_pair) for i in currents} for port_pair in tqdm(port_pairs)}
filename = datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S IV sweep')
pickle.dump({'data':data}, open(filename + '.pickle', 'wb'))

# Plot
for pp, d in data.items():
    fig = plt.figure(); fig.set_size_inches([12,8])
    plt.axhline(0, color='lightgray')
    plt.axvline(0, color='lightgray')
    for i, iv_data in d.items():
        V, I = iv_data
        plt.plot(V*1e3, I*1e6,'.', label = 'Ibias = %0.1f uA' % (i*1e6))
    plt.xlabel('Voltage (mV)')
    plt.ylabel('Current (uA)')
    plt.title('Ports (%s, %s)' % pp)
    
    plt.legend()

    fig_filename = filename + (' Ports %s+%s' % pp)
    pickle.dump(fig, open(fig_filename + '.fig.pickle', 'wb'))
    plt.savefig(fig_filename)
    
#%%============================================================================
# Measure resistance around zero voltage
#==============================================================================

voltage_range = 20e-3

#for n in range(len(V_list)):
#    V = V_list[n]
#    I = I_list[n]
mask = (V < voltage_range) & (V > -voltage_range)
p = np.polyfit(V[mask], I[mask], deg = 1)
resistance = 1/p[0]
print('Resistance around zero %0.2f Ohm)' % (resistance))
    
    
    

#%% OPTIONAL:  Set up SRS-based high-impedance IV curve

from amcc.instruments.srs_sim970 import SIM970
from amcc.instruments.srs_sim928 import SIM928

vs_slot = 4
dmm_slot = 7
dmm_channel = 2

dmm = SIM970('GPIB0::4', dmm_slot)
vs = SIM928('GPIB0::4', vs_slot)

dmm.set_impedance(gigaohm=True, channel = dmm_channel)
dmm.set_impedance(gigaohm=True, channel = 4)


def run_iv_sweep_srs(voltages, R_series, delay = 0.75):
    vs.reset()
    vs.set_output(True)
    time.sleep(2)
    V = []
    I = []
    for v in voltages:
        vs.set_voltage(v)
        time.sleep(delay)
        v1 = dmm.read_voltage(channel = 4)
        v1 = v
        v2 = dmm.read_voltage(channel = dmm_channel)
        V.append(v2)
        I.append((v1-v2)/R_series)
    vs.set_voltage(0)
    return np.array(V),np.array(I)

def iv(port, voltages, R_series, delay = 0.75):
    if port is not None:
        switch.select_port(port, switch = 1)
    V, I = run_iv_sweep_srs(voltages, R_series, delay = delay)
    return V, I


#%% Run single sweep
voltages = np.linspace(0.0,1.9,41)
voltages = np.concatenate([voltages, voltages[::-1], -voltages, -voltages[::-1]])
R_series = 10e3

V,I = iv(port = None, voltages = voltages, R_series = R_series, delay = 1)
figure()
plot(V*1e3,I*1e6,'.-')
xlabel('Voltage (mV)')
ylabel('Current (uA)')

R_iv, voffset = np.polyfit(I,V, deg = 1)

filename = datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S SRS IV sweep')
pickle.dump({'data':data}, open(filename + '.pickle', 'wb'))
pickle.dump(fig, open(filename + '.fig.pickle', 'wb'))
plt.savefig(filename)


#%% Run SRS-based high-impedance IV curve
    
#ports = list(range(1,11))
ports = [1,2,3]
voltages = np.linspace(-0.1,0.1,11)
R_series = 1e3

#ports = [1,3,5,7,9]
data = {port : iv(port, voltages, R_series, delay = 1) for port in tqdm(ports)}
plot_iv_vs_port(data)

# Calculate resistances of each port
for port, d in data.items():
    V = d[0]
    I = d[1]
    R_iv, voffset = np.polyfit(I,V, deg = 1)
    print('Port %s: %0.3f' % (port, R_iv))

